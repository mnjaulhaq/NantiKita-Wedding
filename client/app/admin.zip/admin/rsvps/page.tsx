"use client";

import { useEffect, useState } from "react";
import { apiFetch } from "@/lib/api";
import { formatRelatif } from "@/lib/format";

type RsvpWithWedding = {
  id: number;
  namaTamu: string;
  alamat: string;
  status: string;
  jumlahHadir: number;
  ucapan: string | null;
  createdAt: string;
  wedding: { namaPria: string; namaWanita: string };
};

export default function GlobalRsvpsPage() {
  const [rsvps, setRsvps] = useState<RsvpWithWedding[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    apiFetch("/api/admin/rsvps")
      .then((res) => res.json())
      .then((json) => {
        setRsvps(json.data || []);
        setLoaded(true);
      });
  }, []);

  return (
    <div className="w-full bg-white p-6 rounded-xl shadow-sm border border-gray-100">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-800">🌍 Pusat Kendali RSVP Global</h2>
        <p className="text-sm text-gray-500 mt-1">
          Memantau seluruh aktivitas konfirmasi kehadiran dan doa restu dari semua website undangan klien{" "}
          <strong>NantiKita.</strong>
        </p>
      </div>

      <div className="overflow-x-auto rounded-lg border border-gray-200">
        <table className="w-full text-left border-collapse bg-white">
          <thead className="bg-gray-50 text-xs font-semibold text-gray-600 uppercase tracking-wider border-b border-gray-200">
            <tr>
              <th className="p-4">Target Undangan Klien</th>
              <th className="p-4">Nama Tamu</th>
              <th className="p-4">Konfirmasi</th>
              <th className="p-4">Jumlah Hadir</th>
              <th className="p-4">Isi Ucapan</th>
              <th className="p-4">Waktu</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 text-sm text-gray-700">
            {rsvps.map((r) => (
              <tr key={r.id} className="hover:bg-gray-50/75 transition">
                <td className="p-4 font-semibold text-brand-green">
                  {r.wedding.namaPria} &amp; {r.wedding.namaWanita}
                </td>
                <td className="p-4 font-medium text-gray-900">
                  {r.namaTamu}
                  {r.alamat && <div className="text-xs font-normal text-gray-400">{r.alamat}</div>}
                </td>
                <td className="p-4">
                  <StatusBadge status={r.status} />
                </td>
                <td className="p-4">{r.jumlahHadir} Orang</td>
                <td className="p-4 italic text-gray-600 max-w-xs truncate" title={r.ucapan ?? ""}>
                  &quot;{r.ucapan ?? "-"}&quot;
                </td>
                <td className="p-4 text-xs text-gray-400">{formatRelatif(r.createdAt)}</td>
              </tr>
            ))}
            {loaded && rsvps.length === 0 && (
              <tr>
                <td colSpan={6} className="p-8 text-center text-gray-400">
                  Belum ada data konfirmasi masuk dari undangan manapun.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  return status === "hadir" ? (
    <span className="px-2 py-0.5 text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 rounded">
      Hadir
    </span>
  ) : (
    <span className="px-2 py-0.5 text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200 rounded">
      Absen
    </span>
  );
}
