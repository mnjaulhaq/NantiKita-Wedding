"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { apiFetch } from "@/lib/api";
import LogoutButton from "@/components/LogoutButton";
import { formatRupiah, formatTanggalPendek } from "@/lib/format";

type Wedding = {
  id: number;
  namaPria: string;
  namaWanita: string;
  tema: string;
  paket: string;
  slug: string;
  tanggalAcara: string;
};

type Dashboard = {
  totalWeddings: number;
  totalRevenue: number;
  totalGuestsHadir: number;
  recentWeddings: Wedding[];
};

export default function AdminDashboard() {
  const [data, setData] = useState<Dashboard | null>(null);

  useEffect(() => {
    apiFetch("/api/admin/dashboard")
      .then((res) => res.json())
      .then((json) => setData(json.data));
  }, []);

  if (!data) return <p className="text-sm text-gray-500">Memuat...</p>;

  return (
    <div className="w-full space-y-8">
      <div>
        <h2 className="text-3xl font-extrabold text-gray-800 tracking-tight">Selamat Datang di Dasbor Utama 🌿</h2>
        <p className="text-sm text-gray-500 mt-1">
          Berikut adalah rangkuman performa bisnis dan operasional layanan undangan <strong>NantiKita.</strong>
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard
          label="Total Klien Aktif"
          value={data.totalWeddings}
          unit="Pasangan"
          icon="📋"
          iconClass="bg-brand-green/10 text-brand-green"
        />
        <StatCard
          label="Estimasi Omzet Kasar"
          value={formatRupiah(data.totalRevenue)}
          valueClass="text-brand-green"
          icon="💰"
          iconClass="bg-emerald-50 text-emerald-700"
        />
        <StatCard
          label="Total Tamu Hadir (Fix)"
          value={data.totalGuestsHadir}
          unit="Orang"
          icon="📨"
          iconClass="bg-blue-50 text-blue-700"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold text-gray-800 mb-4">✨ Registrasi Klien Terbaru</h3>
          <div className="divide-y divide-gray-100">
            {data.recentWeddings.length === 0 && (
              <p className="text-sm text-gray-400 text-center py-6">Belum ada aktivitas pendaftaran klien baru.</p>
            )}
            {data.recentWeddings.map((w) => (
              <div key={w.id} className="py-3 flex justify-between items-center first:pt-0 last:pb-0">
                <div>
                  <p className="font-semibold text-gray-900 text-sm">
                    {w.namaPria} &amp; {w.namaWanita}
                  </p>
                  <p className="text-xs text-gray-400 mt-0.5">
                    Tema: <span className="capitalize font-medium">{w.tema}</span> | {formatTanggalPendek(w.tanggalAcara)}
                  </p>
                </div>
                <span
                  className={`px-2.5 py-1 text-xs font-semibold rounded-full capitalize ${
                    w.paket === "premium"
                      ? "bg-amber-50 text-amber-700 border border-amber-100"
                      : "bg-blue-50 text-blue-700 border border-blue-100"
                  }`}
                >
                  {w.paket}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col justify-between">
          <div>
            <h3 className="text-lg font-bold text-gray-800 mb-2">🚀 Akses Cepat</h3>
            <p className="text-xs text-gray-400 mb-4">Pintasan praktis untuk mempercepat alur kerja harian admin.</p>
            <div className="space-y-2">
              <Link
                href="/admin/weddings/create"
                className="block w-full text-center bg-brand-green hover:bg-stone-700 text-white font-medium text-xs py-3 rounded-xl transition"
              >
                Tambah Undangan Baru
              </Link>
              <Link
                href="/admin/weddings"
                className="block w-full text-center bg-gray-50 hover:bg-gray-100 text-gray-700 border border-gray-200 font-medium text-xs py-3 rounded-xl transition"
              >
                Kelola Semua Client
              </Link>
            </div>
          </div>
          <div className="mt-6">
            <LogoutButton />
          </div>
          <div className="text-[10px] text-gray-400 text-center mt-6 pt-4 border-t border-gray-100">
            Logged in as: <strong>Owner NantiKita.</strong>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  unit,
  icon,
  iconClass,
  valueClass = "text-gray-800",
}: {
  label: string;
  value: string | number;
  unit?: string;
  icon: string;
  iconClass: string;
  valueClass?: string;
}) {
  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between">
      <div className="space-y-2">
        <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">{label}</p>
        <p className={`text-3xl font-black ${valueClass}`}>
          {value} {unit && <span className="text-sm font-normal text-gray-400">{unit}</span>}
        </p>
      </div>
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl font-bold ${iconClass}`}>
        {icon}
      </div>
    </div>
  );
}
