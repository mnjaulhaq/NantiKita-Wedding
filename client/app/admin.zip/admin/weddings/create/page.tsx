import WeddingForm from "@/components/WeddingForm";

export default function CreateWeddingPage() {
  return (
    <div className="max-w-3xl bg-white p-8 rounded-xl shadow-md border border-gray-100">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">✨ Buat Undangan Pengantin Baru</h2>
      <WeddingForm mode="create" />
    </div>
  );
}
