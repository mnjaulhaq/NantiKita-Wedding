"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { apiFetch, API_URL } from "@/lib/api";
import { getToken } from "@/lib/auth-client";
import { formatRelatif } from "@/lib/format";

type Rsvp = {
  id: number;
  namaTamu: string;
  alamat: string;
  status: string;
  jumlahHadir: number;
  ucapan: string | null;
  createdAt: string;
};

type Wedding = {
  id: number;
  namaPria: string;
  namaWanita: string;
  rsvps: Rsvp[];
};

export default function WeddingRsvpsPage() {
  const params = useParams<{ id: string }>();
  const [wedding, setWedding] = useState<Wedding | null>(null);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    apiFetch(`/api/admin/weddings/${params.id}/rsvps`).then(async (res) => {
      if (!res.ok) return setNotFound(true);
      const json = await res.json();
      setWedding(json.data);
    });
  }, [params.id]);

  if (notFound) return <p className="text-sm text-red-600">Data klien tidak ditemukan.</p>;
  if (!wedding) return <p className="text-sm text-gray-500">Memuat...</p>;

  // Link unduh PDF butuh token lewat query string karena ini <a> biasa, bukan fetch.
  const pdfHref = `${API_URL}/api/admin/weddings/${wedding.id}/pdf?token=${encodeURIComponent(getToken() || "")}`;

  const totalHadir = wedding.rsvps.filter((r) => r.status === "hadir").reduce((sum, r) => sum + r.jumlahHadir, 0);
  const totalTidakHadir = wedding.rsvps.filter((r) => r.status === "tidak_hadir").length;

  return (
    <div className="w-full bg-white p-6 rounded-xl shadow-sm border border-gray-100">
      <div className="mb-6 flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
        <div>
          <Link
            href="/admin/weddings"
            className="text-xs text-brand-green font-medium hover:underline flex items-center space-x-1 mb-2"
          >
            <span>←</span> <span>Kembali ke Data Client</span>
          </Link>
          <h2 className="text-2xl font-bold text-gray-800">📨 Daftar Kehadiran Tamu (RSVP)</h2>
          <p className="text-sm text-gray-500 mt-1">
            Pernikahan:{" "}
            <span className="font-semibold text-brand-green">
              {wedding.namaPria} &amp; {wedding.namaWanita}
            </span>
          </p>
        </div>
        <a
          href={pdfHref}
          className="bg-brand-green hover:bg-stone-700 text-white font-medium px-4 py-2.5 rounded-lg shadow transition text-sm w-max"
        >
          📄 Unduh PDF
        </a>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-xl">
          <p className="text-xs font-semibold text-emerald-700 uppercase">Total Tamu Hadir</p>
          <p className="text-2xl font-bold text-emerald-900 mt-1">{totalHadir} Orang</p>
        </div>
        <div className="bg-rose-50 border border-rose-100 p-4 rounded-xl">
          <p className="text-xs font-semibold text-rose-700 uppercase">Berhalangan Hadir</p>
          <p className="text-2xl font-bold text-rose-900 mt-1">{totalTidakHadir} Tamu</p>
        </div>
        <div className="bg-stone-50 border border-stone-200 p-4 rounded-xl">
          <p className="text-xs font-semibold text-stone-600 uppercase">Total Ucapan Masuk</p>
          <p className="text-2xl font-bold text-stone-800 mt-1">{wedding.rsvps.length} Ucapan</p>
        </div>
      </div>

      <div className="overflow-x-auto rounded-lg border border-gray-200">
        <table className="w-full text-left border-collapse bg-white">
          <thead className="bg-gray-50 text-xs font-semibold text-gray-600 uppercase tracking-wider border-b border-gray-200">
            <tr>
              <th className="p-4">Nama Tamu</th>
              <th className="p-4">Status Konfirmasi</th>
              <th className="p-4">Jumlah Hadir</th>
              <th className="p-4">Ucapan / Doa Restu</th>
              <th className="p-4">Waktu Mengisi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 text-sm text-gray-700">
            {wedding.rsvps.map((r) => (
              <tr key={r.id} className="hover:bg-gray-50/75 transition">
                <td className="p-4 font-medium text-gray-900">
                  {r.namaTamu}
                  {r.alamat && <div className="text-xs font-normal text-gray-400">{r.alamat}</div>}
                </td>
                <td className="p-4">
                  {r.status === "hadir" ? (
                    <span className="px-2 py-0.5 text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200 rounded">
                      Hadir
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 text-xs font-medium bg-rose-50 text-rose-700 border border-rose-200 rounded">
                      Absen
                    </span>
                  )}
                </td>
                <td className="p-4">{r.jumlahHadir} Orang</td>
                <td className="p-4 italic text-gray-600 max-w-xs truncate" title={r.ucapan ?? ""}>
                  &quot;{r.ucapan ?? "-"}&quot;
                </td>
                <td className="p-4 text-xs text-gray-400">{formatRelatif(r.createdAt)}</td>
              </tr>
            ))}
            {wedding.rsvps.length === 0 && (
              <tr>
                <td colSpan={5} className="p-8 text-center text-gray-400">
                  Belum ada tamu yang mengisi konfirmasi kehadiran (RSVP).
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
