"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { apiFetch } from "@/lib/api";
import { confirmDelete, errorPopup, toastSuccess } from "@/lib/alert";
import { formatTanggal } from "@/lib/format";

type Wedding = {
  id: number;
  namaPria: string;
  namaWanita: string;
  tanggalAcara: string;
  tema: string;
  paket: string;
  slug: string;
};

export default function WeddingsIndexPage() {
  const [weddings, setWeddings] = useState<Wedding[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [origin, setOrigin] = useState("");

  useEffect(() => {
    setOrigin(window.location.origin);
    // ASUMSI: GET /api/admin/weddings mengembalikan { data: Wedding[] }
    apiFetch("/api/admin/weddings")
      .then((res) => res.json())
      .then((json) => {
        setWeddings(json.data || []);
        setLoaded(true);
      });
  }, []);

  async function copyLink(w: Wedding) {
    const url = `${origin}/wedding/${w.slug}?theme=${w.tema}&paket=${w.paket}&to=NamaTamu`;
    try {
      await navigator.clipboard.writeText(url);
      toastSuccess("Tautan undangan berhasil disalin!");
    } catch (err) {
      console.error("Gagal menyalin teks: ", err);
    }
  }

  async function onDelete(id: number) {
    if (!(await confirmDelete())) return;
    const res = await apiFetch(`/api/admin/weddings/${id}`, { method: "DELETE" });
    if (!res.ok) return errorPopup("Data klien belum bisa dihapus.");
    setWeddings((list) => list.filter((w) => w.id !== id));
    toastSuccess("Data klien berhasil dihapus.");
  }

  return (
    <div className="w-full bg-white p-6 rounded-xl shadow-sm border border-gray-100">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">📋 Data Client</h2>
          <p className="text-sm text-gray-500 mt-1">Daftar semua pengantin yang menggunakan jasa NantiKita.</p>
        </div>
        <Link
          href="/admin/weddings/create"
          className="bg-brand-green hover:bg-stone-700 text-white font-medium px-4 py-2.5 rounded-lg shadow transition flex items-center space-x-2 text-sm"
        >
          <span>[+]</span> <span>Tambah Undangan Baru</span>
        </Link>
      </div>

      <div className="overflow-x-auto rounded-lg border border-gray-200">
        <table className="w-full text-left border-collapse bg-white">
          <thead className="bg-gray-50 text-xs font-semibold text-gray-600 uppercase tracking-wider border-b border-gray-200">
            <tr>
              <th className="p-4">Nama Pengantin</th>
              <th className="p-4">Tanggal Acara</th>
              <th className="p-4">Tema Desain</th>
              <th className="p-4">Paket</th>
              <th className="p-4">Link Undangan</th>
              <th className="p-4 text-center">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 text-sm text-gray-700">
            {weddings.map((w) => (
              <tr key={w.id} className="hover:bg-gray-50/75 transition">
                <td className="p-4 font-medium text-gray-900">
                  {w.namaPria} &amp; {w.namaWanita}
                </td>
                <td className="p-4">{formatTanggal(w.tanggalAcara)}</td>
                <td className="p-4 capitalize">
                  <span className="px-2.5 py-1 text-xs font-medium bg-stone-100 text-stone-800 rounded-full">
                    {w.tema}
                  </span>
                </td>
                <td className="p-4">
                  {w.paket === "premium" ? (
                    <span className="px-2.5 py-1 text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200 rounded-full flex items-center w-max space-x-1">
                      <span>👑</span> <span>Premium</span>
                    </span>
                  ) : (
                    <span className="px-2.5 py-1 text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200 rounded-full flex items-center w-max space-x-1">
                      <span>📦</span> <span>Basic</span>
                    </span>
                  )}
                </td>
                <td className="p-4">
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      readOnly
                      value={`${origin}/wedding/${w.slug}`}
                      className="bg-gray-50 border border-gray-200 rounded px-2 py-1 text-xs text-gray-600 w-48 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => copyLink(w)}
                      className="px-3 py-1 bg-stone-50 text-stone-700 border border-stone-200 hover:bg-stone-100 transition rounded-md text-xs font-semibold flex items-center space-x-1"
                    >
                      <span>📋</span> <span>Copy</span>
                    </button>
                  </div>
                </td>
                <td className="p-4">
                  <div className="flex items-center justify-center space-x-2">
                    <Link
                      href={`/admin/weddings/${w.id}/rsvps`}
                      className="text-stone-700 hover:text-stone-900 font-medium text-xs bg-stone-50 hover:bg-stone-100 px-2.5 py-1.5 rounded transition"
                    >
                      RSVP
                    </Link>
                    <Link
                      href={`/admin/weddings/${w.id}/edit`}
                      className="text-blue-600 hover:text-blue-900 font-medium text-xs bg-blue-50 hover:bg-blue-100 px-2.5 py-1.5 rounded transition"
                    >
                      Edit
                    </Link>
                    <button
                      type="button"
                      onClick={() => onDelete(w.id)}
                      className="px-3 py-1 bg-rose-50 text-rose-600 border border-rose-200 hover:bg-rose-100 transition rounded-md text-xs font-semibold"
                    >
                      Hapus
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {loaded && weddings.length === 0 && (
              <tr>
                <td colSpan={6} className="p-8 text-center text-gray-400">
                  Belum ada data client. Klik &quot;Tambah Undangan Baru&quot; untuk memulai.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
