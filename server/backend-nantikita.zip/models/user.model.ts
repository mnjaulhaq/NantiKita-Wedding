import { db } from "../config/db";

export function findUserByUsername(username: string) {
  return db.user.findUnique({ where: { username } });
}

export function findUserByEmail(email: string) {
  return db.user.findUnique({ where: { email } });
}

export function findUserById(id: number) {
  return db.user.findUnique({ where: { id } });
}

export function createUser(data: { name: string; username: string; email: string; password: string }) {
  return db.user.create({ data });
}

export function markEmailVerified(id: number) {
  return db.user.update({ where: { id }, data: { emailVerifiedAt: new Date() } });
}

export function deleteUsersByUsername(username: string) {
  return db.user.deleteMany({ where: { username } });
}
